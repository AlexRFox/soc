Module Description: 
	DTWI Demo is a project to demonstrate how to communicate
	via TWI using the DTWI module of the Adept SDK and an	
	I/O Explorer board.

Hardware Setup:							
	Connect pins 1 and 2 of  J2 on the PmodCLS to the SCL and SDK
	pins on connector J12 of the I/O Explorer. Connect pins 5 and
	6 of J2 on the PmodCLS to GND and 3V3 on the I/O Explorer.
	Additionally, jumpers MD0 and MD1 on the PmodCLS need to be
	shorted, and MD2 open, for the demo to work.
													