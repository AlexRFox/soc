Module Description: 
	Enum Demo is a project to demonstrate how to enumerate
	connected devices using the DMGR module of the Adept SDK.

Hardware Setup:
	This demo will enumerate any connected Digilent USB devices, as well
	as any stored in the device table. The demo will execute fine without
	a device attached, but will only display useful information when one or
	more devices are connected.